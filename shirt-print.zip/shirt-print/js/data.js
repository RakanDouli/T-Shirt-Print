 export const list_items=[
    {   
        img:'/img/vectorstock_204-removebg-preview.png',
        name:'Abstract',
        designer:'Mark Welsh',
        Price:"23",
        tags:"#FineArt #Abstract",
        info:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit id sit, voluptatem distinctio culpa vel?',
        Id:1
    },
    {
        img:'/img/Artboard38.png',
        name:'Statue of librety',
        designer:'Tony hulk',
        Price:"30",
        tags:"#Freedom #USA",
        info:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit id sit, voluptatem distinctio culpa vel?',
        Id:2
    },
    {
       
        img: '/img/3.png',
        name:'Christmas',
        designer:'Sam Shark',
        Price:"15",
        tags:"#Superman #Santa",
        info:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit id sit, voluptatem distinctio culpa vel?',
        Id:3

    },
    {
        img:'/img/vectorstock_21176167-removebg-preview.png',
        name:'Water Color',
        designer:'Khabib Nao',
        Price:"56",
        tags:"#Watercolors #Art",
        info:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit id sit, voluptatem distinctio culpa vel?',
        Id:4

    },
    {   
        img:'/img/4.png',
        name:'Skull',
        designer:'Walles blush',
        Price:"28",
        tags:"#Colors #Skull",
        info:'Dolor sit amet, consectetur adipisicing elit. Reprehenderit id sit, voluptatem distinctio culpa vel?',
        Id:5
    },
    {
        img:'/img/vectorstock_33820488-removebg-preview.png',
        name:'Cute Dog',
        designer:'Tomas Shine',
        Price:"32",
        tags:"#Poppy #Doq",
        info:'Ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit id sit, voluptatem distinctio culpa vel?',
        Id:6
    },
    {
       
        img: '/img/3.png',
        name:'Christmas',
        designer:'Sam Shark',
        Price:"15",
        tags:"#Superman #Santa",
        info:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit id sit, voluptatem distinctio culpa vel?',
        Id:7

    },
    {
        img:'/img/vectorstock_21176167-removebg-preview.png',
        name:'Water Color',
        designer:'Khabib Nao',
        Price:"56",
        tags:"#Watercolors #Art",
        info:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit id sit, voluptatem distinctio culpa vel?',
        Id:8
    }
];
